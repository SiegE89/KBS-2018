function [mu,sig,Kt,Kc] = ckaweigthedK(Xc,L)

Q = numel(Xc);
N = size(Xc{1},1);
U = eye(N)-(ones(N,1)*ones(1,N))*(1/N);
L = double(L);
L = U*L*U;
%compute kernels
for j = 1 : Q
    D = pdist(Xc{j});
    sig(j)= median(D);
    Kc{j}= exp(-squareform(D).^2/(2*sig(j)^2));
    Kcc{j} = U*Kc{j}*U;
    a(j,1) = trace(Kcc{j}*L)/sqrt((trace(Kcc{j}*Kcc{j})*trace(L*L)));
end

for i = 1 : Q
    for j = 1 : Q
        if j >= i
           M(i,j) = trace(Kcc{i}*Kcc{j})/sqrt((trace(Kcc{j}*Kcc{j})*trace(Kcc{i}*Kcc{i})));
        else
            M(i,j) = M(j,i);
        end
    end
end

% sa = M\a;
% mua = sa/norm(sa);
%compute weights as QP for convex combination
H = 2*M;
f = -2*a;
lb = 0;
ub = 1;
Aeq = ones(1,Q);
%Aeq = [];
%beq = [];
beq = 1;
x0 = (1/Q)*ones(Q,1);
mu = quadprog(H,f,[],[],Aeq,beq,lb,ub,x0);

%mu = a;
%mu = [0,1,0],
mu = abs(mu);
mu = mu/norm(mu);
mu = mu/sum(mu);
Kt = zeros(N);
for j = 1 : Q
   Kt =  Kt + mu(j)*Kc{j};
end



