function [Xtrain,Xtest,muc,stc] = cell2matMK_ind(Xc,itrain,itest)
Q = numel(Xc);
for j = 1 : Q
    Xtrain{j,1} = Xc{j}(itrain,:);
    Xtest{j,1} = Xc{j}(itest,:);
    %% Normalization
    [Xtrain{j,1},muc{j},stc{j}] = zscore(Xtrain{j,1});
    stc{j}(abs(stc{j})<1e-13) = 1; %evitar problemas de normalizaci�n
    Xtest{j,1} = (Xtest{j,1} - repmat(muc{j},size(Xtest{j,1},1),1))./repmat(stc{j},size(Xtest{j,1},1),1);
end