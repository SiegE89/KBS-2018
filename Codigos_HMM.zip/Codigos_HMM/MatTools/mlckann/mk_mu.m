function [Kt,Kc] = mk_mu(Xc1,Xc2,sig,mu)

Q = length(Xc1);
Kt = zeros(size(Xc1{1},1),size(Xc2{1},1));
for i = 1 : Q
    D = pdist2(Xc1{i},Xc2{i});
    Kc{i} = exp(-D.^2/(2*sig(i)^2));
    Kt = Kt + mu(i)*Kc{i};
end