function [k_opt,sig_opt,ac_opt] = findparknn_nested(X,Y)
np = 10; %# folds
indices = crossvalind('Kfold',size(Y,1),np);
D = pdist(X);
sigi = median(D);%initial sigma
D = squareform(D);
sigv = linspace(0.1*sigi,sigi,10);
kv = 5:2:11;

acm = zeros(numel(kv),numel(sigv));

for i = 1 : np
    %tic
    Dtrain = D(indices~=i,indices~=i);
    Ytrain = Y(indices~=i);
    Dtest = D(indices~=i,indices==i);
    Ytest = Y(indices==i);
    for z = 1 : numel(sigv)%loop sigma
        sig = sigv(z);
        Ktest = exp(-Dtest.^2/(2*sig^2));
        for j = 1 : numel(kv)%loop lambda
            %% knn
            %training the model
            ltest = A_kernel_knn(Ktest,Ytrain,kv(j),'mode');
            
            acm(j,z,i) = 100*sum(ltest == Ytest)/numel(Ytest);
        end
    end
end
%% Best parameters
ac = mean(acm,3);
[ac_opt,ind] = max(ac(:));
[ki,si] = ind2sub(size(acm),ind);
k_opt = kv(ki);
sig_opt = sigv(si);
