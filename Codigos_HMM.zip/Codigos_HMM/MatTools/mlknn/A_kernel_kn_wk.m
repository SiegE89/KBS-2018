function [esty_test,w_train_test] = A_kernel_kn_wk(Ktrain_test,Ytrain,k)
% K-nearest neighbor approx in RKHS
% kernel: esty_test = mean(wiyi); Omega: set of K neighbors of

[~,itrain_test] = sort(Ktrain_test,'descend'); %training samples vs testing samples

nt = size(Ktrain_test,2);

for i = 1 : nt
    w_train_test(:,i) = Ktrain_test(itrain_test(1:k,i),i)./sum(Ktrain_test(itrain_test(1:k,i),i));
    
    esty_test(i,:) = w_train_test(:,i)'*Ytrain(itrain_test(1:k,i),:);
    
end
