function [nnC] = cal_nnC_k(nC,ltest)

for ii = 1 : length(nC)
       nnC(ii,1) = sum(ltest == nC(ii));
end