function [lteste] = teste_Total(ltesteF,ltesteOP,C1,C2)

    mat =zeros(C2,C1);
    
    cont=1;
    for i = 1:C1 % number of classes
    for j = 1:C2
    mat(j,i)= cont;  
    cont=cont+1;
    end
    end
    
     for i=1:length(ltesteF)   
    lteste(i,1) = mat(ltesteOP(i),ltesteF(i));
     end
    
    
    end