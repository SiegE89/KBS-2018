function [prior_opt, transmat_opt, mu_opt, Sigma_opt, mixmat_opt,par_opt,ac,acm] =...
    findparhmm_nested(X,Y,maxiter,tol,cov_type,method,Q,M)
% X= Xtrain
% Y= ltrain
np = 10; %# subfolds

indices = A_crossval_bal(Y,np); %np-fold partition
acm = zeros(numel(Q), np);

%%
for i = 1 : np
    
    fprintf('SubFold %d/%d\n',i,np)
    tic
    Xtrain = X(:,:,indices~=i);
    Ytrain = Y(indices~=i,1);
    Xtest = X(:,:,indices==i);
    Ytest = Y(indices==i,1); 
    par.M = M;
     
    for j = 1:numel(Q) %loop states
            
        %% classification
        fprintf('State for train %d/%d\n', j, numel(Q))
        
        % training the model
        [prior, transmat, mu, Sigma, mixmat] = A_hmm_mat_multiclass_k(Xtrain,Ytrain,Q(j),...
         par.M,cov_type,maxiter,tol,method);
        
        % testing the model
        label_est = A_hmmclassify_multi_k(Xtest, prior, transmat, mu, Sigma, mixmat);
        
       % accuracy measure 1FP
        acm(j,i) = 100*sum(label_est == Ytest)/size(Ytest,1);
           
    end
    
    tc = toc
    fprintf('%d/%d\n',i,np)
end
% Best parameters 1PL

ac = mean(acm,2);
[ac_opt,ind] = max(ac(:));
[li,si] = ind2sub(size(ac),ind);
par_opt = [Q(li), M];

%% train best hmm

[prior_opt, transmat_opt, mu_opt, Sigma_opt, mixmat_opt] = ...
    A_hmm_mat_multiclass_k(X,Y,par_opt(1),par_opt(2),cov_type,maxiter,tol,method);

