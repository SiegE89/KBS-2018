function [prior, transmat, mu, Sigma, mixmat] = A_hmm_mat_multiclass_OP(X,y,Q,M,...
    cov_type,maxiter,tol,method,C1,C2)

%% Entradas
% X: training data (O,T,Nex)
% y: training labels
% Q: state vector
% M : # gaussians per state
% nex: # of sequences

%% 
%clc
% numero de clases para fallas

labels =zeros(length(y),1);
 

for i = 1:C2 % number of Operational condition
    cont=0;
for j = 1:C1
    labels(y==cont+i)=i;
    cont=cont+C2;
end
end

clearvars y
y=labels;

la = unique(y);
ncla = length(la);

%inicializacion

% hmm parameter prelocation
prior = cell(ncla,1);
transmat = cell(ncla,1);
mu = cell(ncla,1);
mixmat = cell(ncla,1);
Sigma = cell(ncla,1);

%% hmm

for i = 1 : ncla
    
    % Data for the clasees
    Xthmm = X(:,:,y == i);
    x = cell(1,size(Xthmm,3));
    obs=[];
    for j=1:size(Xthmm,3)
    x{j}(:,:) = Xthmm(:,:,j);
    obs = [obs, x{j}];
    end
    
    if i==1
    % Initializing HMM.
    prior0 = normalise(rand(Q,1));
    transmat0 = mk_stochastic(rand(Q,Q));
    if M == 1
    mixmat0 = ones(Q,1);
    else
    mixmat0 = mk_stochastic(rand(Q,M));
    end
    end
    
    [D, T] = size(obs);
    [mu0, Sigma0] = mixgauss_init(Q*M, obs, cov_type, method);
    mu0 = reshape(mu0, [D Q M]);
    Sigma0 = reshape(Sigma0, [D D Q M]);
    
   %training the model
   [~, prior{i,1}, transmat{i,1}, mu{i,1}, Sigma{i,1}, mixmat{i,1}] = ...
    mhmm_em(x, prior0, transmat0, mu0, Sigma0, mixmat0,'max_iter', maxiter,...
    'cov_type', cov_type,'thresh', tol,'verbose',0);

end


end


