function [ltestOP] = test_OP(ltest,C1,C2)

    labels =zeros(length(ltest),1);
    
    for i = 1:C2 % number of operational conditions
    cont=0;
    for j = 1:C1
    labels(ltest==cont+i)=i;
    cont=cont+C2;  
    end
    end
    ltestOP=labels;
end
    
 