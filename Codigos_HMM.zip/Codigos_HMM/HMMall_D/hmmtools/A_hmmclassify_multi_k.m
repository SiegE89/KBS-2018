% Evaluate the classifier
% outputs
%label_est: estimated labels

function [label_est] = A_hmmclassify_multi_k(x,prior,transmat,mu,Sigma,mixmat)

ncla = length(prior);
nt = size(x,3);
label_est = zeros(nt,1);

if ~iscell(x)    %Each secuence of the 3rd dim gets its own cell 
    data =cell(1,nt);
    for j=1:nt
    data{j}(:,:) = x(:,:,j);
    end 
end      

for i = 1 : nt
 
loglik = zeros(1,ncla);

for m = 1:ncla % compute the log Prob of each secuence with each model
  loglik(m) = mhmm_logprob(data(i),prior{m},transmat{m},mu{m},Sigma{m},mixmat{m});
end
    [~,im] = max(loglik);
    label_est(i,1) = im; % estimated labels
end
