function [ltestF] = test_F(ltest,C1,C2)

    labels =zeros(length(ltest),1);
    cont=0;
    for i = 1:C1 % number of classes
    for j = 1:C2
    labels(ltest==cont+j)=i;   
    end
    cont=cont+C2;
    end
    clearvars y
    ltestF=labels;
    end